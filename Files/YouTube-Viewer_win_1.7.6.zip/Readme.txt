---------------------------------------------------------------------------
                           YouTube Viewer
---------------------------------------------------------------------------
GitHub - https://github.com/MShawon/YouTube-Viewer
Donation -
	PayPal : https://paypal.me/mshawon1
	Bitcoin : 1Jh8KZ6khuHayNDeVV9tEzYSq9FPExKCAH

Usage:
-------
You can use exe by clicking double click as any other exe.
You need to click yes when firewall ask for permission this is required by python request module.

Another way would be.. Open a cmd in this directory then run youtube_viewer.exe. This is better
because if something goes wrong you will be able to see the errors.

Edit search.txt and url.txt according to your need.

After closing program, if chromedrivers are still running. You may want to double click killdrive.bat 
to close all chrome instances. This will also your Google Chrome if it's running.

For more detailed instructions please visit GitHub repo and if you face any issue check GitHub issues 
first.